# Tutorials

A good way to familiarize yourself with SpeechBrain is to take a look at the Colab tutorials that we made available. More tutorials will be made available as the project will progress.

The full list of tutorials can be found on the official [website](https://speechbrain.github.io). All the tutorials are developed on the [Google Colab platform](https://colab.research.google.com). This allows users to directly try SpeechBrain on GPUs without the need to set up an environment.

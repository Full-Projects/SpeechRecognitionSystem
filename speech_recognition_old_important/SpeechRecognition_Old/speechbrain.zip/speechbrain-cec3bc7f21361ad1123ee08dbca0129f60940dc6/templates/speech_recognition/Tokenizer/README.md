# Tokenizer.
This folder contains the scripts to train a tokenizer using SentencePiece (https://github.com/google/sentencepiece).
The tokenizer is trained on the top of the training transcriptions.

# How to run
python train.py tokenizer.yaml

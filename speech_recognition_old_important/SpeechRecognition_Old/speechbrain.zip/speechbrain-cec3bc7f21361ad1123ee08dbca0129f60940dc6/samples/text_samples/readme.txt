hdf5_example.h5 contains an example of hdf5 format dataset for text-only data.
The structure of the file is as followed.

hdf5_example.h5 - wrd - "good morning"
		 		- "good evening"
		  - char - "g o o d _ m o r n i n g"
		         - "g o o d _ e v e n i n g"

The label_dict.pkl is used for HDF5 dataloader and dataset.

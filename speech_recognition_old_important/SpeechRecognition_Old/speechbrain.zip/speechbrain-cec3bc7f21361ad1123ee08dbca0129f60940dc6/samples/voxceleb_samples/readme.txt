
This a small sample data containing 6 audio clips taken from the subset of voxceleb1 dataset (http://www.robots.ox.ac.uk/~vgg/data/voxceleb/) which is distributed under Creative Commons Attribution 4.0 International License (https://creativecommons.org/licenses/by/4.0/). 
In this sample data, we have edited train-dev-test split in the iden_split_sample.txt file. Please refer http://www.robots.ox.ac.uk/~vgg/data/voxceleb/ for more information on the complete original dataset.


## RTTM Files
###### The sample RTTM files given in this directory are generated from manual annotations from AMI corpus (http://groups.inf.ed.ac.uk/ami/corpus/). 
###### The AMI corpus and its annotations are released under the Creative Commons Attribution 4.0 International Public License agreement (CC BY 4.0).  Use of this data implies agreement with the terms below. See also: https://creativecommons.org/licenses/by/4.0/

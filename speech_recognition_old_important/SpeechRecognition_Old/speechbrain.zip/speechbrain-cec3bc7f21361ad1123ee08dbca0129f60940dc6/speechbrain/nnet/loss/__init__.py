"""Package containing specific losses (transducer, stoi ...)
"""
